"use strict"
const domTextOut = document.getElementById("txtOut");
domTextOut.innerHTML = `
<p>Hello JavaScript version ECMAScript 6!</p>
<p>Successfully running modules in a Live Server environment.</p>
<p style="text-align: center;">🎉</p> 
`;
