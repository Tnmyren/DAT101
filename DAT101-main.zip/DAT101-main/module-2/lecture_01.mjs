
"use strict"
import {printOut} from "../../common/script/utils.mjs";

//Create a function that print hello World to console
function printHelloWorld() {
    printOut("Hello World");
}
